package OutputProcessor.StrategyPattern;

//Strategy pattern
//Abstract class

import DataStore.*;

public interface DisposeDrink {
//	Interface method to dispose drink
	public void DisposeDrink(int d);
}
