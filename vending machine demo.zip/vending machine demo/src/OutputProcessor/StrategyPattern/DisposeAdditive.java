package OutputProcessor.StrategyPattern;

//Strategy pattern
//Abstract class

import DataStore.*;

public interface DisposeAdditive {
//	Interface method to dispose additive
	public void DisposeAdditive(int [] array);
}
